import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import {CrudService} from '../../services/crud.service'
import { Router } from '@angular/router';
 

@Component({
  selector: 'app-userinfo',
  templateUrl: './userinfo.component.html',
  styleUrls: ['./userinfo.component.css']
})
export class UserinfoComponent implements OnInit {

  public user: any;
  public userName: string;
  public userAge: number;
  public userAddress: string;
  public msg: string;
  public showUser:boolean = false;

  constructor(public authservice: AuthService, private router: Router, public crudServices: CrudService) { }


  ngOnInit() {
    this.crudServices.get_allUser().subscribe(data => {
      this.user = data.map(u => {
        return {
          id: u.payload.doc.id,
          isedit: false,
          name: u.payload.doc.data()['name'],
          age: u.payload.doc.data()['age'],
          address: u.payload.doc.data()['address'],

        };
      })
      console.log(this.user);
    })


  }

  createRecord()
  {
    this.showUser = true;
    let data = {};
    data['name'] = this.userName;
    data['age'] = this.userAge;
    data['address'] = this.userAddress;

    this.crudServices.create_newUser(data).then(res => {
      this.userName= "";
      this.userAge= undefined;
      this.userAddress="";
      console.log(res);
      this.msg = "User Details Saved Successfully"
    }).catch(error => {
      console.log(error);
    })

  }
  
  editRecord(data)
  {
  data.isedit = true;
  data.editName = data.name;
  data.editAge = data.age;
  data.editAddress = data.address;

  }
  updateRecord(updatedata)
  {
    let update ={};
    update['name'] = updatedata.editName;
    update['age'] = updatedata.editAge;
    update['address'] = updatedata.editAddress;
    this.crudServices.update_User(updatedata.id, update);
    updatedata.isedit=false;

  }
  deleteRecord(item_id)
  {
this.crudServices.delete_User(item_id);
this.msg="";
this.showUser = false;
  }

}
