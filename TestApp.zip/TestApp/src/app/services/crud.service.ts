import { Injectable } from '@angular/core';
import {AngularFirestore} from '@angular/fire/firestore'

@Injectable({
  providedIn: 'root'
})
export class CrudService {

  constructor(public fireService: AngularFirestore) { }

  create_newUser(data)
  {
    return this.fireService.collection('Employee').add(data);
  }
  get_allUser()
  {
    return this.fireService.collection('Employee').snapshotChanges();
  }
  update_User(id, data)
  {
    this.fireService.doc('Employee/' + id).update(data);
  }
  delete_User(id)
  {
    this.fireService.doc('Employee/' + id).delete();
  }

}
